export const MAX_POS = 4;
