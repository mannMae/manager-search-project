export function getRandomInteger(from, to) {
  return Math.floor(Math.random() * to + from);
}
